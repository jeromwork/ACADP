/**
 * Gutenberg Blocks
 */

import './blocks/locations/index.js';
import './blocks/categories/index.js';
import './blocks/listings/index.js';
import './blocks/search-form/index.js';
import './blocks/listing-form/index.js';