<?php

/**
 * Markup the manage venues page.
 */ 
?>
<!--<script src="https://maps.googleapis.com/maps/api/js"></script>-->
<div id="map-canvas"></div>